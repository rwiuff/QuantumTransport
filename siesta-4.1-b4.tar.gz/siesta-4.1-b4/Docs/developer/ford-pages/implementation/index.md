title: Specific implementation details

The details of the implementation that are specific to Siesta may be found here.

Contrary to the [data structures](|page|/datastructures/index.html), the documentation found
here is not easily transferable to other codes.
